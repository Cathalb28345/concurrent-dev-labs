var searchData=
[
  ['updatetask',['updateTask',['../main_8cpp.html#a37e1a7011bf9a799a50b02ab574c7806',1,'main.cpp']]]
];
