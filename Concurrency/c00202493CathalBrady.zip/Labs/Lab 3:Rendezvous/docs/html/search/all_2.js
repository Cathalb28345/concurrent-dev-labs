var searchData=
[
  ['taskone',['taskOne',['../main_8cpp.html#a456ff38e4b077f54fbe0aeef41edce3b',1,'main.cpp']]],
  ['tasktwo',['taskTwo',['../main_8cpp.html#a0a8aa9d1171c7a9244fda2d221f9d0fd',1,'main.cpp']]]
];
